const Overlay = document.querySelector(".PopupOverlay");

// Add Plane Popup Start
const OpenPopup = document.querySelector(".AddPlane");
const ClosePopup = document.querySelector(".CloseAddPlanePopup");

if(OpenPopup)
{
    OpenPopup.addEventListener('click', () => {
    Overlay.style.display = 'flex';
    document.body.classList.add('DisableScroll');
    });
}

if(ClosePopup)
{
    ClosePopup.addEventListener('click', () => {
    Overlay.style.display = 'none';
    document.body.classList.remove('DisableScroll');
    });
}
// Add Plane Popup End

const UserIcon = document.querySelector(".UserIcon");
const CloseAccountView = document.querySelector(".CloseAccountView");

if(UserIcon)
{
    UserIcon.addEventListener('click', () => {
        const UserName = document.querySelector(".UserName");
        const Email = document.querySelector(".Email");

        UserName.textContent = `مرحبآ ${localStorage.getItem("UserName")}`;
        Email.textContent = localStorage.getItem("UserEmail");

        Overlay.style.display = 'flex';
        document.body.classList.add('DisableScroll');
    });
}

if(CloseAccountView)
{
    CloseAccountView.addEventListener('click', () => {
        Overlay.style.display = 'none';
        document.body.classList.remove('DisableScroll');
    });
}

