import {db} from "./BackendConfig.js";

class User{
    constructor()
    {
        this.UserID = "";
        this.UserName = "";
        this.UserEmail = "";
        this.UserPassword = "";
        this.CreatedAt = "";
    }

    async AddNewUser()
    {
        const {data, error} = await db.from('Users').insert([{
            Name: this.UserName,
            Email: this.UserEmail,
            Password: this.UserPassword
        }]).select('*');

        if(error)
            console.log(error);
        else
            this.UserID = data[0].id;
    };

    async DeleteUser(ID)
    {
        const {data, error} = await db.from('Users').delete().eq('id', ID)
        
       if(error)
            console.log(error);
    }

    ChangePassword()
    {

    }

    SendEmail()
    {

    }
}

export {User};