// import {db} from "./Backend/BackendConfig.js";
import {User} from "./Backend/clsUsers.js";
import {ShowAlert} from "./CustomAlert.js";
import { ShowLoader, HideLoader } from './CustomLoader.js';

const NavBarLinks = document.querySelectorAll('.NavBtn');
NavBarLinks.forEach(btn => {
    btn.addEventListener('click', () => {
        NavBarLinks.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    });
});

function execCmd(command, value = null) {
    document.execCommand(command, false, value);
}

//Validations
function validateEmail(Email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(Email);
}

function validatePassword(password) {
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const isLongEnough = password.length >= 8;

    return hasUpperCase && hasLowerCase && hasNumber && isLongEnough;
}

function isFieldEmpty(field) {
    return field.trim() === "";
}

// Pass in Start
const PassToSys = document.querySelector('.PassBtn');

// Register Start
function validateUserData(Name, Email, Password, ConfirmPassword)
{
  if(isFieldEmpty(Name) || isFieldEmpty(Email) || isFieldEmpty(Password) || isFieldEmpty(ConfirmPassword))
  {
    ShowAlert("يجب ملئ جميع الحقول", "error");
    return false;
  }

  if(!validateEmail(Email))
  {
    ShowAlert("البريد الإلكتروني غير صحيح", "error");
    return false;
  }

  if(!validatePassword(Password))
  {
    ShowAlert("كلمة المرور يجب أن تحتوي على 8 خانات على الأقل، وتتضمن حروفاً كبيرة وصغيرة، وأرقاماً.", "error");
    return false;
  }

  if(ConfirmPassword != Password)
  {
    ShowAlert("يجب ان يتطابق حقل كلمة المرور مع حقل تأكيد كلمة المرور.", "error");
    return false;
  }

  return true
}

async function HashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

if(PassToSys)
{
  PassToSys.addEventListener('click', async () =>{
    const Name = document.querySelector(".Name").value;
    const Email = document.querySelector(".Email").value;
    const Password = document.querySelector(".Password").value;
    const ConfirmPassword = document.querySelector(".ConfirmPassword").value;

    if(!validateUserData(Name, Email, Password, ConfirmPassword))
      return;

    const NewUser = new User();
    NewUser.UserName = Name;
    NewUser.UserEmail = Email;
    NewUser.UserPassword = HashPassword(Password);

    ShowAlert("تم إنشاء الحساب بنجاح", "success");
    ShowLoader();
    await NewUser.AddNewUser();

    localStorage.setItem("UserID", NewUser.UserID);
    localStorage.setItem("UserName", NewUser.UserName);
    localStorage.setItem("UserEmail", NewUser.UserEmail);

    HideLoader();
    window.location.href = "../Main/Main.html";
  });
};

const Signout = document.querySelector(".Signout");
if(Signout)
{
  Signout.addEventListener('click', () => {
    localStorage.clear();
    window.location.href = "../Landing.html";
  });
}

const DeleteAccount = document.querySelector(".DeleteAccount");
if(DeleteAccount)
{
  DeleteAccount.addEventListener('click', () => {
    const CurrentUser = new User();
    if(confirm("هل انت متاكد؟ سيتم حذف جميع البيانات المتعلقة بهذا الحساب"))
    {
      CurrentUser.DeleteUser(localStorage.getItem("UserID"));
      localStorage.clear();
      window.location.href = "../Landing.html";
    }
  });
}