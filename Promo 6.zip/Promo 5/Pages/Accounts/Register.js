import {User} from "../../Js/Backend/clsUsers.js";
import {HashPassword} from '../../Js/Global.js';
import {validateEmail, validatePassword, isFieldEmpty} from '../../Js/Validations.js';
import {ShowAlert} from "../../Js/CustomAlert.js";
import { ShowLoader, HideLoader } from '../../Js/CustomLoader.js';

function validateUserRegisterData(Name, Email, Password, ConfirmPassword)
{
  if(isFieldEmpty(Name) || isFieldEmpty(Email) || isFieldEmpty(Password) || isFieldEmpty(ConfirmPassword))
  {
    ShowAlert("يجب ملئ جميع الحقول", "error");
    return false;
  }

  if(!validateEmail(Email))
  {
    ShowAlert("البريد الإلكتروني غير صحيح", "error");
    return false;
  }

  if(!validatePassword(Password))
  {
    ShowAlert("كلمة المرور يجب أن تحتوي على 8 خانات على الأقل، وتتضمن حروفاً كبيرة وصغيرة، وأرقاماً.", "error");
    return false;
  }

  if(ConfirmPassword != Password)
  {
    ShowAlert("يجب ان يتطابق حقل كلمة المرور مع حقل تأكيد كلمة المرور.", "error");
    return false;
  }

  return true
}

const Register = document.querySelector('.Register');
Register.addEventListener('click', async () =>{
    const Name = document.querySelector(".Name").value;
    const Email = document.querySelector(".Email").value;
    const Password = document.querySelector(".Password").value;
    const ConfirmPassword = document.querySelector(".ConfirmPassword").value;

    if(!validateUserRegisterData(Name, Email, Password, ConfirmPassword))
        return;

    const HashedPassword = await HashPassword(Password);
    const NewUser = new User();

    ShowLoader();
    const result = await NewUser.Signup(Name, Email, HashedPassword);
    if(result)
    {
        ShowAlert("تم إنشاء الحساب بنجاح", "success");
        // window.location.href = "../Main/Main.html";
    }
    else
    {
        ShowAlert("حدثت مشكلة أثناء إنشاء الحساب تواصل ب 730020957", "error");
    }
    HideLoader();
});