import {User} from "../../Js/Backend/clsUsers.js";
import {HashPassword} from '../../Js/Global.js';
import {validateEmail, isFieldEmpty} from '../../Js/Validations.js';
import {ShowAlert} from "../../Js/CustomAlert.js";
import { ShowLoader, HideLoader } from '../../Js/CustomLoader.js';

function validateUserSigninData(Email, Password)
{
  if(isFieldEmpty(Email) || isFieldEmpty(Password))
  {
    ShowAlert("يجب ملئ جميع الحقول", "error");
    return false;
  }

  if(!validateEmail(Email))
  {
    ShowAlert("البريد الإلكتروني غير صحيح", "error");
    return false;
  }

  return true;
}

const Signin = document.querySelector(".Signin");
Signin.addEventListener('click', async () => {
    const Email = document.querySelector(".Email").value;
    const Password = document.querySelector(".Password").value;
    if(!validateUserSigninData(Email, Password))
        return;

    const HashedPassword = await HashPassword(Password);
    const CurrentUser = new User();

    ShowLoader();
    const result = await  CurrentUser.Signin(Email, HashedPassword);
    HideLoader();
    if(!result)
       ShowAlert("كلمة المرور او البريد الألكتروني غير صحيح", "error");

    ShowAlert("تم تسجيل الدخول بنجاح", "success");
    window.location.href = "../Main/Main.html";
});