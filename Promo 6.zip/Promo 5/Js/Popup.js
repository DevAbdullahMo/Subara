// AddPlane Start
const OpenPopup = document.querySelector(".AddPlane");
if(OpenPopup)
{
    OpenPopup.addEventListener('click', () => {
        const AddPlanePopup = document.createElement("div");
        AddPlanePopup.classList.add("PopupOverlay");
        AddPlanePopup.innerHTML = `
            <div class="Popup">
                <i class="ri-close-large-line CloseAddPlanePopup"></i>
                <div class="TitleArea">
                    <h3 class="PopupTitle">إضافة صنف</h3>
                </div>
                <div class="InputArea">
                    <input type="text" class="TextBox NewPlaneInput" placeholder="أسم الصنف">
                    <button class="Btn SecondryBtn PopupAddPlane">إضافة</button>
                </div>
            </div>
        `;

        document.body.appendChild(AddPlanePopup);
        document.body.classList.add('DisableScroll');

        const ClosePopup = document.querySelector(".CloseAddPlanePopup");
        if(ClosePopup)
        {
            ClosePopup.addEventListener('click', () => {
                const AddPlanePopup = document.querySelector(".PopupOverlay");
                if (AddPlanePopup) AddPlanePopup.remove();
                document.body.classList.remove('DisableScroll');
            });
        }
    });
}
// AddPlane End

//AccountView Start
const UserIcon = document.querySelector(".UserIcon");
if(UserIcon)
{
    UserIcon.addEventListener('click', () => {
        const AccountViewPopup = document.createElement("div");
        AccountViewPopup.classList.add("PopupOverlay");
        AccountViewPopup.innerHTML = `
            <div class="AccountView">
                <i class="ri-close-large-line CloseAccountView"></i>
                <div class="Titles">
                    <h2 class="TitleText UserName"></h2>
                    <p class="SecondryText">من هنا يمكنك إدارة حسابك</p>
                </div>
                <hr>
                <div class="UserInfo">
                    <p class="SecondryText">البريد الألكتروني</p>
                    <p class="SecondryText Email"></p>

                    <div class="AccountActions">
                        <button class="Btn SecondryBtn Signout">تسجيل الخروج</button>
                        <button class="Btn SecondryBtn DeleteAccount">حذف الحساب</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(AccountViewPopup);

        const UserName = document.querySelector(".UserName");
        const Email = document.querySelector(".Email");
        UserName.textContent = `مرحبآ ${localStorage.getItem("UserName")}`;
        Email.textContent = localStorage.getItem("UserEmail");

        document.body.classList.add('DisableScroll');
        
        const CloseAccountView = document.querySelector(".CloseAccountView");
        if(CloseAccountView)
        {
            CloseAccountView.addEventListener('click', () => {
                const AccountViewPopup = document.querySelector(".PopupOverlay");
                if (AccountViewPopup) AccountViewPopup.remove();
                document.body.classList.remove('DisableScroll');
            });
        }
    });
}
//AccountView End

//Add
