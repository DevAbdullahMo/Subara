import {User} from "./Backend/clsUsers.js";
import {ShowAlert} from "./CustomAlert.js";
import { ShowLoader, HideLoader } from './CustomLoader.js';

//Nav Links Activation
const NavBarLinks = document.querySelectorAll('.NavBtn');
NavBarLinks.forEach(btn => {
    btn.addEventListener('click', () => {
        NavBarLinks.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    });
});

// End Seisson
const Signout = document.querySelector(".Signout");
if(Signout)
{
  Signout.addEventListener('click', () => {
    localStorage.clear();
    window.location.href = "../Landing.html";
  });
}

const DeleteAccount = document.querySelector(".DeleteAccount");
if(DeleteAccount)
{
  DeleteAccount.addEventListener('click', () => {
    const CurrentUser = new User();
    if(confirm("هل انت متاكد؟ سيتم حذف جميع البيانات المتعلقة بهذا الحساب"))
    {
      CurrentUser.DeleteUser(localStorage.getItem("UserID"));
      localStorage.clear();
      window.location.href = "../Landing.html";
    }
  });
}

//Product Img
const UploadBtn = document.querySelector(".UploadProductImg");
const FileInput = document.querySelector(".FileInput");
if(UploadBtn)
{
  UploadBtn.addEventListener('click', () => {
    FileInput.click();
  });

  FileInput.addEventListener('click', () => {
    
  });
}