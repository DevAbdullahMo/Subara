import {db} from "./BackendConfig.js";

class User{
    constructor()
    {
       
    }

    async Signup(UserName, UserEmail, UserPassword)
    {
        const {data, error} = await db.from('Users').insert([{
            Name: UserName,
            Email: UserEmail,
            Password: UserPassword
        }]).select('*');

        if(error)
        {
            console.log(error);
            return false
        }
        else
        {
            localStorage.setItem("UserID", data[0].id);
            localStorage.setItem("UserName", UserName);
            localStorage.setItem("UserEmail", UserEmail);
            return true;
        }
    };

    async Signin(Email, hashedPassword) {
        const {data, error} = await db.from('Users').select('*').eq('Email', Email).eq('Password', hashedPassword);
        if (error) {
            console.log(error);
            return false;
        }
        if (data && data.length > 0) {
            const user = data[0];
            localStorage.setItem("UserID", user.id);
            localStorage.setItem("UserName", user.Name);
            localStorage.setItem("UserEmail", user.Email);
            console.log(user.id, user.Name, user.Email);
            return true;
        } else {
            return false;
        }
    }

    async DeleteUser(ID)
    {
        const {data, error} = await db.from('Users').delete().eq('id', ID);
        
       if(error)
            console.log(error);
    }

    async IsUserExist(UserID, Email)
    {
        const {data, error} = await db.from('Users').select('*').eq('id', UserID, 'Email', Email);

        if(error)
            console.log(error);
        else
            return true;
    }
}

export {User};