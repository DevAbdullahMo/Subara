import {User} from "./Backend/clsUsers.js";
import {ShowAlert} from "./CustomAlert.js";
import { ShowLoader, HideLoader } from './CustomLoader.js';
import {validateEmail, validatePassword, isFieldEmpty} from './Validations.js';
import {HashPassword} from './Global.js';

//Nav Links Activation
const NavBarLinks = document.querySelectorAll('.NavBtn');
NavBarLinks.forEach(btn => {
    btn.addEventListener('click', () => {
        NavBarLinks.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    });
});

// Register
function validateUserRegisterData(Name, Email, Password, ConfirmPassword)
{
  if(isFieldEmpty(Name) || isFieldEmpty(Email) || isFieldEmpty(Password) || isFieldEmpty(ConfirmPassword))
  {
    ShowAlert("يجب ملئ جميع الحقول", "error");
    return false;
  }

  if(!validateEmail(Email))
  {
    ShowAlert("البريد الإلكتروني غير صحيح", "error");
    return false;
  }

  if(!validatePassword(Password))
  {
    ShowAlert("كلمة المرور يجب أن تحتوي على 8 خانات على الأقل، وتتضمن حروفاً كبيرة وصغيرة، وأرقاماً.", "error");
    return false;
  }

  if(ConfirmPassword != Password)
  {
    ShowAlert("يجب ان يتطابق حقل كلمة المرور مع حقل تأكيد كلمة المرور.", "error");
    return false;
  }

  return true
}

const Register = document.querySelector('.Register');
if(Register)
{
  Register.addEventListener('click', async () =>{
    const Name = document.querySelector(".Name").value;
    const Email = document.querySelector(".Email").value;
    const Password = document.querySelector(".Password").value;
    const ConfirmPassword = document.querySelector(".ConfirmPassword").value;

    if(!validateUserRegisterData(Name, Email, Password, ConfirmPassword))
      return;

    const NewUser = new User();
    ShowAlert("تم إنشاء الحساب بنجاح", "success");

    ShowLoader();
    await NewUser.Signup(Name, Email, HashPassword(Password));
    HideLoader();
    
    window.location.href = "../Main/Main.html";
  });
};

// Signin
function validateUserSigninData(Email, Password)
{
  if(isFieldEmpty(Email) || isFieldEmpty(Password))
  {
    ShowAlert("يجب ملئ جميع الحقول", "error");
    return false;
  }

  if(!validateEmail(Email))
  {
    ShowAlert("البريد الإلكتروني غير صحيح", "error");
    return false;
  }
}

const Signin = document.querySelector('.Signin');
if(Signin)
{
  Signin.addEventListener('click', async () => {
    const Email = document.querySelector(".Email").value;
    const Password = document.querySelector(".Password").value;
    if(!validateUserSigninData(Email, Password))
      return;

    ShowAlert("تم تسجيل الدخول بنجاح", "success");
    
    ShowLoader();
    await CurrentUser.Signin(Email, Password);
    HideLoader();

    window.location.href = "../Main/Main.html";
  });
}

// End Seisson
const Signout = document.querySelector(".Signout");
if(Signout)
{
  Signout.addEventListener('click', () => {
    localStorage.clear();
    window.location.href = "../Landing.html";
  });
}

const DeleteAccount = document.querySelector(".DeleteAccount");
if(DeleteAccount)
{
  DeleteAccount.addEventListener('click', () => {
    const CurrentUser = new User();
    if(confirm("هل انت متاكد؟ سيتم حذف جميع البيانات المتعلقة بهذا الحساب"))
    {
      CurrentUser.DeleteUser(localStorage.getItem("UserID"));
      localStorage.clear();
      window.location.href = "../Landing.html";
    }
  });
}