import {db} from "./BackendConfig.js";

class User{
    constructor()
    {
       
    }

    async Signup(UserName, UserEmail, UserPassword)
    {
        const {data, error} = await db.from('Users').insert([{
            Name: UserName,
            Email: UserEmail,
            Password: UserPassword
        }]).select('*');

        if(error)
            console.log(error);
        else{
            localStorage.setItem("UserID", data[0].id);
            localStorage.setItem("UserName", UserName);
            localStorage.setItem("UserEmail", UserEmail);
        }
    };

    async Signin(Email, Password) {
        const {data, error} = await db.from('Users').select('*').eq('Email', Email, 'Password', Password);
        if(error)
            console.log(error);
        else
        {
            localStorage.setItem("UserID", data.id);
            localStorage.setItem("UserName", data.Name);
            localStorage.setItem("UserEmail", Email);
        }
    }

    async DeleteUser(ID)
    {
        const {data, error} = await db.from('Users').delete().eq('id', ID);
        
       if(error)
            console.log(error);
    }

    async IsUserExist(UserID, Email)
    {
        const {data, error} = await db.from('Users').select('*').eq('id', UserID, 'Email', Email);

        if(error)
            console.log(error);
        else
            return true;
    }
}

export {User};