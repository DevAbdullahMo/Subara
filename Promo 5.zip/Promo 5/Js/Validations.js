import {HashPassword} from './Global.js';

export function validateEmail(Email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(Email);
}

export function validatePassword(password) {
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const isLongEnough = password.length >= 8;

    return hasUpperCase && hasLowerCase && hasNumber && isLongEnough;
}

export function eqPassword(dbPassword, InputPassword)
{
    return (HashPassword(InputPassword) == dbPassword);
}

export function isFieldEmpty(field) {
    return field.trim() === "";
}